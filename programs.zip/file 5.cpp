#include<iostream>
#include<conio.h>
using namespace std;
template<class t1,class t2>
void mult(t1 a,t2 b)
{
cout<<"Product="<<a*b<<endl;
return 0;
}
int main()
{ int a,b;
float x,y;
cout<<"Enter 2 integer data";
cin>>a>>b;
cout<<"Enter 2 float data";
cin>>x>>y;
mult(a,b)
mult(x,y)
mult(a,x)
getch():
return 0;
}
