#include<iostream>
using namespace std;
class person
{
	public:
		person()
		{
			cout << "Name of the person : " << endl;
		}
};
class student
{
	public:
		student()
		{
			cout << "Name of the student : " << endl;
		}
};
class faculty
{
	public:
		faculty()
		{
			cout << "Name of the faculty : " << endl;
		}
};
int main()
{
	student c;
	return 0;
}
